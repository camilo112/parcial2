import 'package:flutter/material.dart';
import 'package:practica/Provider/currency_provider.dart';
import 'package:practica/pages/dolar_page.dart';
import 'package:practica/pages/euro_page.dart';
import 'package:provider/provider.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  //
  //
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CurrencyProvider(),
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          // This is the theme of your application.
          primarySwatch: Colors.red,
        ),
        home: MyHomePage(),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text('conversor de moneda'),
            bottom: TabBar(
              tabs: <Widget>[
                Tab(
                  icon: Icon(Icons.monetization_on_outlined),
                ),
                Tab(
                  icon: Icon(Icons.euro),
                ),
              ],
              onTap: (index) {
                context.read<CurrencyProvider>().reset();
              },
            ),
          ),
          body: TabBarView(
            children: [
              DolarPage(),
              EuroPage(),
            ],
          ),
        ));
  }
}
