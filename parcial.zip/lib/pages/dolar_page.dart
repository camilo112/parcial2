import 'package:flutter/material.dart';
import 'package:practica/Provider/currency_provider.dart';

import 'package:provider/provider.dart';

class DolarPage extends StatelessWidget {
  DolarPage({Key? key}) : super(key: key);
  final searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final currency = context.watch<CurrencyProvider>();
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: searchController,
                    decoration: const InputDecoration(
                        hintText: "Buscar Moneda en Dolar"),
                  ),
                ),
                ElevatedButton(
                    onPressed: () {
                      context
                          .read<CurrencyProvider>()
                          .getCurrency(searchController.text, "USD");
                    },
                    child: const Text("Enviar"))
              ],
            ),
            ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: currency.currencys.rates.length,
                itemBuilder: (shapshot, index) {
                  return ListTile(
                      title: Row(
                    children: [
                      Text(currency.currencys.rates[index].name),
                      const SizedBox(width: 10),
                      Text(currency.currencys.rates[index].amount.toString()),
                    ],
                  ));
                })
          ],
        ),
      ),
    );
  }
}
