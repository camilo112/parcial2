class CurrencyModel {
  CurrencyModel({
    this.amount = 0,
    this.base = "",
    this.date = "",
    this.rates = const [],
  });

  late int amount;
  late String base;
  late String date;
  late List<Rates> rates;

  CurrencyModel.fromJson(Map<String, dynamic> json) {
    amount = json["amount"];
    base = json["base"];
    date = json["date"];
    rates = format(json["rates"]);
  }

  List<Rates> format(Map<String, dynamic> rates) {
    List<Rates> aux = [];
    rates.forEach((key, value) {
      aux.add(Rates(name: key, amount: value));
    });
    print(aux);
    return aux;
  }
}

class Rates {
  late String name;
  late double amount;
  Rates({required this.name, required this.amount});
}
