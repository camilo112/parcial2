import 'package:flutter/material.dart';
import 'package:practica/Model/currency_model.dart';
import 'package:practica/data/currency_service.dart';

class CurrencyProvider with ChangeNotifier {
  final currencyService = CurrencyService();

  CurrencyModel _currency = CurrencyModel();

  CurrencyModel get currencys => _currency;
  //methods of bitton
  void getCurrency(String amount, String base) async {
    final response = await currencyService.getCurrency(amount, base);
    _currency = response;
    notifyListeners();
  }

  void reset() {
    _currency = CurrencyModel();
    notifyListeners();
  }
}
