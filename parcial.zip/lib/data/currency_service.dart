import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:practica/Model/currency_model.dart';

class CurrencyService {
  //request module with frankfuter
  Future<CurrencyModel> getCurrency(String amount, String base) async {
    final url = Uri.https(
        "api.frankfurter.app", "/latest", {"amount": amount, "from": base});
    final reponse = await http.get(url);
    final responseDecode = jsonDecode(reponse.body);

    print(responseDecode);
    return CurrencyModel.fromJson(responseDecode);
  }
}
